bap = graph.axis.painter.bar
a = graph.axis.nestedbar(painter=bap(nameattrs=[trafo.rotate(45),
                                                text.halign.right],
                                     innerticklength=0.1))
